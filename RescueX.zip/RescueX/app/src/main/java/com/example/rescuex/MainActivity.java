package com.example.rescuex;


import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomsheet.BottomSheetDialog;

public class MainActivity extends AppCompatActivity {

    private Dialog connectionStatusDialog;
    private Button b1,b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1= findViewById(R.id.button);
        b2 = findViewById(R.id.button3);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b1.setBackgroundTintList(ContextCompat.getColorStateList(MainActivity.this, android.R.color.white));
                b2.setBackgroundTintList(ContextCompat.getColorStateList(MainActivity.this, android.R.color.black));
                b1.setTextColor(ContextCompat.getColorStateList(MainActivity.this, android.R.color.black));
                b2.setTextColor(ContextCompat.getColorStateList(MainActivity.this, android.R.color.white));
                showManPopup();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b2.setBackgroundTintList(ContextCompat.getColorStateList(MainActivity.this, android.R.color.white));
                b1.setBackgroundTintList(ContextCompat.getColorStateList(MainActivity.this, android.R.color.black));
                b2.setTextColor(ContextCompat.getColorStateList(MainActivity.this, android.R.color.black));
                b1.setTextColor(ContextCompat.getColorStateList(MainActivity.this, android.R.color.white));
                showAutoPopup();


            }
        });
        ImageView i1 = findViewById(R.id.imageView7);
        i1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,MainActivity2.class);
                startActivity(i);
            }
        });

        ImageView i2 = findViewById(R.id.imageView8);
        i2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               showBluetootthDevices();
            }
        });
        ImageView i3 = findViewById(R.id.imageView9);
        i3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showBluetoothhDevices();
            }
        });

        ImageView i4 = findViewById(R.id.button2);
        i4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Device On&off", Toast.LENGTH_SHORT).show();
            }
        });



        showConnectionStatusPopup();
    }

    private void showConnectionStatusPopup() {
        connectionStatusDialog = new Dialog(this);
        connectionStatusDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        connectionStatusDialog.setContentView(R.layout.connection_status_popup);

        Button cancelButton = connectionStatusDialog.findViewById(R.id.cancel_button);
        cancelButton.setOnClickListener(v -> connectionStatusDialog.dismiss());

        connectionStatusDialog.show();
    }

    private void showAutoPopup() {
        connectionStatusDialog = new Dialog(this);
        connectionStatusDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        connectionStatusDialog.setContentView(R.layout.autopop);

        Button cancelButton = connectionStatusDialog.findViewById(R.id.cancel_button);
        cancelButton.setOnClickListener(v -> connectionStatusDialog.dismiss());

        connectionStatusDialog.show();
    }
    private void showManPopup() {
        connectionStatusDialog = new Dialog(this);
        connectionStatusDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        connectionStatusDialog.setContentView(R.layout.mannpop);

        Button cancelButton = connectionStatusDialog.findViewById(R.id.cancel_button);
        cancelButton.setOnClickListener(v -> connectionStatusDialog.dismiss());

        connectionStatusDialog.show();
    }

    private void showBluetootthDevices() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.respod);
        Window window = bottomSheetDialog.getWindow();
        window.setGravity(Gravity.RIGHT);
        bottomSheetDialog.show();
    }

    private void showBluetoothhDevices() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.spr);
        Window window = bottomSheetDialog.getWindow();
        window.setGravity(Gravity.RIGHT);
        bottomSheetDialog.show();
    }

}
