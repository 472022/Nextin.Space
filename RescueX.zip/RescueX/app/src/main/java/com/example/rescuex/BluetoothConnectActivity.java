package com.example.rescuex;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Set;

public class BluetoothConnectActivity extends AppCompatActivity {

    private BluetoothAdapter bluetoothAdapter;
    private RecyclerView bluetoothRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth_connect);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        FloatingActionButton connectButton = findViewById(R.id.connect_button);
        TextView skipButton = findViewById(R.id.skip_button);

        connectButton.setOnClickListener(v -> showBluetoothDevices());
        skipButton.setOnClickListener(v -> navigateToNextScreen());
    }

    private void showBluetoothDevices() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.bluetooth_device_list);

        bluetoothRecyclerView = bottomSheetDialog.findViewById(R.id.bluetoothRecyclerView);
        bluetoothRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        if (bluetoothAdapter != null) {
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                startActivityForResult(enableBluetooth, 1);
            }
            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
            if (pairedDevices.size() > 0) {
                BluetoothDeviceAdapter adapter = new BluetoothDeviceAdapter(pairedDevices, device -> {
                    // Handle device selection
                    Toast.makeText(this, "Connected to " + device.getName(), Toast.LENGTH_SHORT).show();
                    bottomSheetDialog.dismiss();
                    navigateToNextScreen();
                });
                bluetoothRecyclerView.setAdapter(adapter);
            }
        }
        bottomSheetDialog.show();
    }

    private void navigateToNextScreen() {
        Intent intent = new Intent(BluetoothConnectActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
